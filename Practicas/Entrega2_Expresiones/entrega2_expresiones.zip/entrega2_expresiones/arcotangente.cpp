/**
  * @file arcotangente.cpp
  * @brief Expresi�n gen�rica incluyendo arco tangente de un racional (Ej 1.19)
  *
  * @author Fulanito...
  * @date Octubre-2020
  *
  * Escriba un programa C ++ que calcule el valor de la siguiente expresi�n:
  * 
  * (v�ase ejercicio 1.19)
  * 
  * Por ejemplo, para los valores a=1, b=2, c=3, e=4, p=5 y �ngulo =6 el resultado 
  * es 2.92803. Para resolver este ejercicio deber� buscar informaci�n sobre las 
  * funciones de biblioteca atan y atan2. Estudie sus diferencias y determine cu�l es
  * la adecuada en este caso.
  */
