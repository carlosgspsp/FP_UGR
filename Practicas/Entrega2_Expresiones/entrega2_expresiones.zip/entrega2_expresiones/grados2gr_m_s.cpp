/**
  * @file grados2gr_m_s.cpp
  * @brief Programa para pasar de grados decimales a grados, minutos, segundos (Ej. 1.16)
  *
  * @author Fulanito...
  * @date Octubre-2020
  *
  * Escriba un programa para convertir los grados decimales a grados, 
  * minutos y segundos. Recuerde que un grado son 60 minutos y un minuto son 
  * 60 segundos. Por ejemplo, si escribimos como entrada 34.567, deber� obtener en la
  * salida 34 grados 34 minutos 1.2 segundos.
  */
