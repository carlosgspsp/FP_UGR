/**
  * @file gaussiana.cpp
  * @brief C�lculo del valor de una gaussiana (Ej. 1.20)
  *
  * @author Fulanito...
  * @date Octubre-2020
  *
  * La expresi�n que define una funci�n gaussiana es la siguiente:
  * 
  * (v�ase ejercicio 1.20)
  * 
  * Con valores 1, 2, 3, el resultado es gaussiana(3)= 0.120985
  */
