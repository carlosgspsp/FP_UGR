/**
  * @file media_desv_3.cpp
  * @brief Programa para calcular media y desviaci�n con 3 valores (Ej. 1.17)
  *
  * @author Fulanito...
  * @date Octubre-2020
  *
  * Lectura de tres valores desde el teclado y salida de dos valores: 
  * la media aritm�tica y la desviaci�n est�ndar. Las expresiones son las siguientes:
  * 
  *  (v�ase ejercicio 1.17)
  */
